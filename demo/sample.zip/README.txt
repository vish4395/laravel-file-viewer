Laravel File Viewer - ZIP demo archive.
This file is used to test archive preview (details panel + download).